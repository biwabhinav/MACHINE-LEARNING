// Time:  O(n + tlogt + flogf)
// Space: O(n)

class Solution {
public:
    vector<vector<string>> displayTable(vector<vector<string>>& orders) {
        map<int, unordered_map<string, int>> table_count;
        set<string> foods;
        for (const auto& order : orders) {
            ++table_count[stoi(order[1])][order[2]];
            foods.emplace(order[2]);
        }
        vector<vector<string>> result = {{"Table"}};
        copy(foods.cbegin(), foods.cend(), back_inserter(result.back()));
        for (const auto& kvp: table_count) {
            result.push_back({to_string(kvp.first)});
            transform(foods.cbegin(), foods.cend(), back_inserter(result.back()),
                      [&kvp](const auto& food) {
                          return to_string(kvp.second.count(food) ? kvp.second.at(food) : 0);
                      });
        }
        return result;
    }
};
