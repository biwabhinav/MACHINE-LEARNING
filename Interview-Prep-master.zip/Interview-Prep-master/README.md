# Interview-Prep
This repository consist of Data Structures and Algorithms question which are being asked in Google, Amazon, Facebook, Microsoft, Shopee, Flipkart etc.

### Math 
