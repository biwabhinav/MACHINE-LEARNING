### Naive Bayes ###

1. Bayes Theorem

2. Independence Assumption in Naive Bayes

3. Probability Estimation for Discrete Valued Features

4. How to Handle Zero Probabilities

5. Implementation of Naive Bayes

6. Finding Probabi;ities to Continious Valued Features

7. Text Classification using Naive Bayes
