### Python Basics ###

1. Welcome to Course

2. Anaconda and Jupyter Notebook

3. Variables

4. Strings and Input

5. String Slicing

6. Tuples
