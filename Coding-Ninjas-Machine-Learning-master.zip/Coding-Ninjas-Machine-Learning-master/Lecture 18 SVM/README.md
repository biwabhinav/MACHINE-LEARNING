### SVM ###

1. Intuition behind SVM

2. SVM Cost Function

3. Decision Boundary & the C Parameter

4. Using SVM from Sklearn

5. Finding Non Linear Decision Boundary

6. Choosing Landmark Points

7. Various Similarity

8. More about Gaussian Similarity function

9. How to move to new Dimensions

10. Multiclass classification

11. Using Sklearn SVM on Iris

12. Choosing Parameters Using Grid Search

13. Using Support Vectors to Regression
