### Unsupervised Learning ###

1. Intro to supervised Learning

2. Introduction to Clustering

3. Using KMeans for Flat Clustering

4. KMeans Algorithm

5. Using KMeans from Sklearn

6. Starter Code for KMeans

7. Implementing Fit & Predict Functions

8. Implementing KMeans Class
