### Conditionals loops and Functions ###
1. Boolean and Operators

2. Conditionals

3. Loops

4. Fast Iterations

5. Functions

6. Variable Sized Input and Output

7. Practice Questions
