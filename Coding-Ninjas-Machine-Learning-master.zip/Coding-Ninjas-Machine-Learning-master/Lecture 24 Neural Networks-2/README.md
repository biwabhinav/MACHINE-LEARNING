### Neural Network-2 ###

1. Forward Propagation-1

2. Forward Propagation-2

3. Error Function in Gradient Descent

4. Derivate of Sigmoid Function

5. Math behind Backpropagation

6. Math behind BackPropagation-2

7. Math behind BackPropagation-3

8. Implementing a Simple Neural Network

9. Optimising Our Codde Using Vector Operation

10. Total Derivates

11. Math behind Backpropagation

12. Implementing a general Neural Network


