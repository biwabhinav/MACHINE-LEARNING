
### Handling Classification Problems ###

1. Handling Classification Problems

2. Logistic Regression

3. Cost Function

4. Finding optimal Values

5. Solving Derivates-1

6. Solving Derivates-2

7. Multiclass Logistic Regression

8. Finding Complex Boundaries and Regularization

9. Using Logistic Regression from Sklearn
