### PCA ###

1. Intuition Behind PCA

2. Applying PCA to 2D data

3. Applying PCA to 3D data

4. Analysis on Breast Cancer Dataset

5. Math Behind PCA

6. Let's Code our own PCA

7. Finding Optimal Number of features

8. Magic Behind PCA
