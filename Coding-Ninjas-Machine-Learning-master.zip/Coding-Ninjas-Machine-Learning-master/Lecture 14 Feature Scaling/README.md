### Feature Scaling ###
1. Feature Scaling

2. Feature Scaling in Sklearn
