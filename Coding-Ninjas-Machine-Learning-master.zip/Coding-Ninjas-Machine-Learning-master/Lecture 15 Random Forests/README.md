### Random Forests ###

1. Introduction to Random Forests

2. Data Bagging and Feature Selection

3. Extra Trees

4. Regression using decision trees and Random Forest

5. Random Forest in Sklearn
