### Tensor Flow ###

1. Intro to Tensor Flow

2. Constants

3. Session

4. Variables

5. Placeholder

6. MNIST Data

7. Initialising Weights and biases

8. Forward Propagation

9. Finding predictions and Accuracy

10. Cost Function

11. Running the Optimizer

12. How the Optimizer Work

13. Running Multiple Iterations

