### Lists and Dictionaries ###
1. Lists 1
2. Lists 2
3. Bubble Sort
4. Dictionaries
5. Practice
