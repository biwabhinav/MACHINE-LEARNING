### LSTM ###

1. Vanishing or Exploiting Gradients

2. Gated Recurrent Units

3. Variations of the GRU

4. LSTM
