### RNN ###

1. Building ML Models for Sequential Data

2. Recurrent Neural Networks

3. How does RNN work

4. Typical RNN structures

5. Airline Data Analysis

6. Preparing Data for RNN

7. Setting up the RNN Model
