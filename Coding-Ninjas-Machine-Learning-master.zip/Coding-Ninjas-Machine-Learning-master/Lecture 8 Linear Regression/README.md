### Linear Regression ###

1. Linear Regression Intuition

2. Analysis of LR using dummy Data

3. Coefficient of Determination

4. Cost Function

5. Optimal Coefficient

6. Coding Linear Regression-1

7. Coding Linear Regression-2

8. Practice
