### Projects ###

[ ] Image Captioning

[ ] Music Generation

[x] Fake news detection

[ ] Recommendation

[ ] Google Stock Prediction

[ ] Email spam/ham
