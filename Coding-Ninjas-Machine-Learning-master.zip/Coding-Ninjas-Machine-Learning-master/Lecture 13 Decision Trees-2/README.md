### Decision Trees-2 ###

1. Code Using Sklearn Decision Tree

2. Information Gain

3. Gain Ratio

4. Gini Index

5. Decision Trees & Overfitting

6. Pruning
