### Introduction to Machine Learning ###

1. Intro to Machine Learning

2. Supervised Learning

3. Steps for Supervised Learning

4. Loading Boston Dataset

5. Training an Algorithm
