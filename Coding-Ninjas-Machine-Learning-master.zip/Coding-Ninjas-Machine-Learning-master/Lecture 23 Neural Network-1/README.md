### Neural Network-1 ###

1. Why do we need neural networks

2. Example with Linear Decision Boundary

3. Finding Non Linear Decision Boundary

4. Neural Network Terminology

5. Number of Parameters in Neural Network

6. Forward and Backward Propagation

7. Cost Function

8. How to Handle Multiclass Classification

9. MLP Classifier in Sklearn

