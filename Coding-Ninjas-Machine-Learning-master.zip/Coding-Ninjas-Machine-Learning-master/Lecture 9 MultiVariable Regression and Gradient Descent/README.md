### MultiVariable Regression and Gradient Descent ###

1. How to find More Complex Boundaries

2. Complexity Analysis of Normal Equation

3. Gradient Descent

4. Learning Rate

5. Code Gradient Descent

6. Generic Gradient Descent

7. Variations of Gradient Descent
