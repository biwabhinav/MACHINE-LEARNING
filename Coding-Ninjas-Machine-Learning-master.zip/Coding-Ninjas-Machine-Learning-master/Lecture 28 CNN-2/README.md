### CNN2 ###

1. Architecture of CNN

2. Initializing Weights

3. Forward Propagation in Tensor Fow

4. Convolution and Maxpool functions

5. Completing Rest of the Code

6. Regularisation using Dropout Layer

7. Adding Dropout Layer to our Network

8. Building CNN Keras
