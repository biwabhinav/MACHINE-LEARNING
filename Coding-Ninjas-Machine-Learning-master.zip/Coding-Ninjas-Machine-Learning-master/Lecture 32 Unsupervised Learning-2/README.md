### Unsupervised Learning ###

1. How to choose K

2. Silhoutte Algorithm to choose k

3. Intro to k Medoids

4. K Medoid Algorithm

5. Intro to Hierarchial Clustering

6. Top Down/Divisive Approach

7. Bottom up/Agglomerative Approach
