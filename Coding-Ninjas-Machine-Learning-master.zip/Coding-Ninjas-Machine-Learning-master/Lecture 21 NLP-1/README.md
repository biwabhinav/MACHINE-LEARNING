### NLP-1 ###

1. Using words as Features

2. Basics of word Processing

3. Stemming

4. Part of Speech

5. Lemmatization

6. Movie Reviews Dataset

7. Movie Reviews Data Cleaning

8. Building Feature Set

9. Classification using NLTK Naive Bayes
