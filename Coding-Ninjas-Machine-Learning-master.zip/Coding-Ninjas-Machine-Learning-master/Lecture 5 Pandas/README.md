###   Pandas  ###

1. Introduction to Pandas 

2. Accessing Data in Pandas

3. Manipulating Data in DataFrame-1

4. Manipulating Data in DataFrame-2

5. Handing NAN

6. Handling Strings in Data

7. Intro to Titanic Dataset
