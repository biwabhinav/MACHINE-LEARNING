### CNN ###

1. Problem in Handling Images

2. Convolution Neural Networks

3. Stride and Padding

4. Channels

5. Pooling Layer

6. Data Flow in CNN

7. Completing our Network
