
### KNN ###

1. Introduction to KNN

2. Feature Scaling before KNN

3. KNN in Sklearn

4. Cross Validation

5. Finding Optimal K

6. Implement KNN

7. Curse of Dimensionality

8. Handling Categorical Data

9. Other Algorithm for KNN

10. Pros & Cons of KNN
