### NLP-2 ###

1. Using Sklearn Classifiers Within NLTK

2. Count Vectorizer

3. Sklearn Classifier

4. N-gram

5. Tf-Idf

