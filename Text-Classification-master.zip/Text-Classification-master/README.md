# Text-Classification
Built a text classifier using Naive Bayes algorithm to classify text into 20 different categories. Achieved accuracy of about 80%.
