# Huffman-Coding
Project implementing Huffman coding, to compress files. This project is aimed to reduce the size of common text files, by using Huffman coding, it involves usage of various data structures like min heap, tree, etc.
NOTE - The file path used in the code is with respect to my system.
